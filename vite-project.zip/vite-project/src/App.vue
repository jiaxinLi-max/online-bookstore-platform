<script setup lang="ts">

</script>

<template>
  <el-container direction="vertical">
    <router-view />
  </el-container>
</template>

<style scoped>
</style>
