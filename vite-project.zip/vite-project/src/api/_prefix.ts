//总api
export const API_MODULE = '/api'

//用户模块
export const USER_MODULE = `${API_MODULE}/users`

export const STORE_MODULE = `${API_MODULE}/stores`

export const PRODUCT_MODULE = `${API_MODULE}/products`